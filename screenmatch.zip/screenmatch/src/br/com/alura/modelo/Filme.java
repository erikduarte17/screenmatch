package br.com.alura.modelo;

public class Filme extends Titulo {

	private String diretor;
	
	public Filme(String nome, int anoDeLancamento, String diretor) {
		super(nome, anoDeLancamento);
		this.diretor = diretor;
	}

	public String getDiretor() {
		return diretor;
	}
	
	@Override
	public String toString() {
		return "Nome: " + this.getNome() + ", ano de lançamento: " + this.getAnoDeLancamento();
	}
	
	
}
