package br.com.alura.modelo;

public class Episodio {


}
