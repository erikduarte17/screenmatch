package br.com.alura.modelo;

public class Serie {

}
